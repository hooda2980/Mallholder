import React from "react";
import Card from "react-bootstrap/Card";
import "../style/Centerbar.css";
import { BsThreeDots } from "react-icons/bs";
import { AiTwotoneLike } from "react-icons/ai";
import { AiOutlineLike } from "react-icons/ai";
import { BiComment } from "react-icons/bi";
import { BsShare } from "react-icons/bs";
const CenterBar = () => {
  return (
    <>
      <div className="center_main_sec">
        <Card className="center_card">
          <div className="d-flex justify-content-between align-items-center">
            <div className="d-flex align-items-center">
              <img
                src="/images/img_avatar2.png"
                alt="image"
                className="center_bar"
              />
              <p className="m-0 username">
                Rahul Roy <br></br> <span>hey there</span>
              </p>
            </div>
            <BsThreeDots />
          </div>
          <p className="m-0 card_top_content text-center mt-md-3">
            Some quick example text to build on the card title
          </p>
          <img
            src="/images/rightbar_image.jpg"
            alt="image"
            className="center_card_img"
          />

          <div className="card_body d-flex justify-content-between align-items-center mt-2">
            <div className="like_icon">
              <AiTwotoneLike />
            </div>
            <div>
              <p className="m-0 comment">
                15 comment <span>13 share</span>
              </p>
            </div>
          </div>
          <hr className="bottom_hr_line"></hr>

          <div className="card_buttons d-flex justify-content-between align-items-center ">
            <div className="d-flex align-items-center card_like_btn d-flex justify-content-center align-items-center">
              <AiOutlineLike />
              <p className="m-0">like</p>
            </div>
            <div className="d-flex align-items-center card_like_btn d-flex justify-content-center align-items-center">
              <BiComment />
              <p className="m-0">Comment</p>
            </div>
            <div className="d-flex align-items-center card_like_btn d-flex justify-content-center align-items-center">
              <BsShare />
              <p className="m-0">Share</p>
            </div>
          </div>
        </Card>
      </div>
    </>
  );
};

export default CenterBar;
