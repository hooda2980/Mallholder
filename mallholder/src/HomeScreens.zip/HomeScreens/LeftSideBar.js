import React from "react";
import "../style/LeftSideBar.css";
import { RiInboxArchiveFill } from "react-icons/ri";
import { GrMail } from "react-icons/gr";
import { RiMailDownloadFill } from "react-icons/ri";

function LeftSideBar() {
  return (
    <>
      <div className="header_left">
        <div className="left_mail_box d-flex align-items-center">
          <RiInboxArchiveFill className="icon" />
          <p className="m-0">Inbox</p>
        </div>
        <div className="left_mail_box d-flex align-items-center">
          <GrMail className="icon" />
          <p className="m-0">Starred</p>
        </div>
        <div className="left_mail_box d-flex align-items-center">
          <RiMailDownloadFill className="icon" />
          <p className="m-0">Send email</p>
        </div>
        <div className="left_mail_box d-flex align-items-center">
          <GrMail className="icon" />
          <p className="m-0">Drafts</p>
        </div>
        <hr className="bottom_hr_line"></hr>
        <div className="left_mail_box d-flex align-items-center">
          <RiMailDownloadFill className="icon" />
          <p className="m-0">All Mail</p>
        </div>
        <div className="left_mail_box d-flex align-items-center">
          <GrMail className="icon" />
          <p className="m-0">Trash</p>
        </div>
        <div className="left_mail_box d-flex align-items-center">
          <RiMailDownloadFill className="icon" />
          <p className="m-0">Spam</p>
        </div>
      </div>
      
    </>
  );
}

export default LeftSideBar;
