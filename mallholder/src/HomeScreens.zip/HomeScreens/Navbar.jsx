import React,{useState} from "react";
import "../style/Home.css";
import { AiOutlineSearch } from "react-icons/ai";
import { AiFillHome} from "react-icons/ai";
import { TbBrandYoutubeFilled} from "react-icons/tb";
import { HiUsers} from "react-icons/hi";
import { BsBasketFill} from "react-icons/bs";


const Navbar = () => {
  const [color, setColor] = useState(false);

  return (
    <>
      <div className="container-fliud nav_bar">
        <nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark ">
          <a class="navbar-brand" href="#">
            MUI
          </a>
          <button
            class="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            {/* right====================================================== */}
            <form class="form-inline my-2 my-lg-0">
              <div className="search_bar">
                <input
                  class="form-control mr-sm-2"
                  type="text"
                  placeholder="Search..."
                  aria-label="Search"
                  onClick={()=> setColor(true)}
                />
               {
                color? <AiOutlineSearch className="search_icon" style={{color:"black"}}/>: <AiOutlineSearch className="search_icon"/>
               }
              </div>
            </form>
            {/* center======================================================= */}
            <ul class="navbar-nav m-lg-auto">
              <li class="nav-item active">
                <a class="nav-link ani_border" href="#">
                  <AiFillHome className="nav_bar_icon"/>
                </a>
              </li>
              <li class="nav-item active">
                <a class="nav-link ani_border" href="#">
                <TbBrandYoutubeFilled className="nav_bar_icon"/>
                </a>
              </li>
              <li class="nav-item active">
                <a class="nav-link ani_border" href="#">
                <BsBasketFill className="nav_bar_icon"/>
                </a>
              </li>
              <li class="nav-item active">
                <a class="nav-link ani_border" href="#">
                <HiUsers className="nav_bar_icon" />
                </a>
              </li>
             
              
              
            </ul>
            {/* left============================================================================= */}
            <div className="d-flex justify-content-center align-items-center menu-avtar">
              <img
                src="/images/img_avatar2.png"
                alt="image"
                className="avatar "
              />
              <p className="m-0 text-white">Rahul Sharama</p>
            </div>
            <ul class="navbar-nav ">
              <li class="nav-item active ">
                <a class="nav-link" href="#">
                  <i class="fa fa-envelope-o">
                    <span class="badge badge-danger">11</span>
                  </i>
                </a>
              </li>

              <li class="nav-item dropdown active">
                <a
                  class="nav-link"
                  href="#"
                  id="navbarDropdown"
                  role="button"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <i class="fa fa-bell">
                    <span class="badge badge-danger">17</span>
                  </i>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="#">
                    Action
                  </a>
                  <a class="dropdown-item" href="#">
                    Another action
                  </a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#">
                    Something else here
                  </a>
                </div>
              </li>

              <li class="nav-item dropdown  icon_dropdown active" >
                <a
                  class="nav-link dropdown-toggle "
                  href="#"
                  id="navbarDropdown "
                  role="button"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                ></a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="#">
                    Action
                  </a>
                  <a class="dropdown-item" href="#">
                    Another action
                  </a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#">
                    Something else here
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </>
  );
};

export default Navbar;
